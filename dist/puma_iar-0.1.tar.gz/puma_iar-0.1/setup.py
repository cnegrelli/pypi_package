from setuptools import setup

setup(name = 'puma_iar',
      version = '0.1',
      description = 'functions for Puma project',
      packages = ['puma_iar'],
      author = 'Carolina Negrelli',
      author_email = 'caro.negrelli@gmail.com',
      zip_safe = False)
